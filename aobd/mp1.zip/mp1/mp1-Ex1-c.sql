CREATE NONCLUSTERED INDEX Nutrients_Calories_IX
ON NutrientsDB.Cheese(Calories)
ON Nutrients_PrimaryFG;

