CREATE PARTITION FUNCTION NutrientsPartitionFunction(INT)
AS RANGE LEFT FOR VALUES(50, 100);

CREATE PARTITION SCHEME NutrientsPartitionScheme
AS PARTITION NutrientsPartitionFunction
TO (Nutrients_PrimaryFG, Nutrients_SecondaryFG1, Nutrients_SecondaryFG1_2);

CREATE TABLE Cheese (
  cheeseID INT PRIMARY KEY,
  Type NVARCHAR(25),
  Calories INT,
  Proteins INT,
  Carbohidrates INT,
  Fat INT
) ON NutrientsPartitionScheme(cheeseID);